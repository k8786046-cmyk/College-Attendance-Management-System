<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Record Leave';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $reason = trim($_POST['reason']);

    if (!$student_id || !$from_date || !$to_date) {
        $error = "Student, From Date and To Date are required.";
    } elseif ($to_date < $from_date) {
        $error = "To Date cannot be before From Date.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO leaves (student_id, from_date, to_date, reason, applied_by, status) VALUES (?,?,?,?, 'Admin', 'Pending')");
        $stmt->execute([$student_id, $from_date, $to_date, $reason]);
        $leaveId = $pdo->lastInsertId();

        // Admin-recorded leave is approved immediately
        $stmt = $pdo->prepare("SELECT * FROM leaves WHERE id = ?");
        $stmt->execute([$leaveId]);
        $leave = $stmt->fetch();
        $reduction = approve_leave($pdo, $leave);

        header("Location: list.php?approved=" . $reduction);
        exit;
    }
}

$students = $pdo->query("SELECT id, name, roll_no FROM students ORDER BY name")->fetchAll();
include '../includes/header.php';
?>

<h3 class="page-title">Record Leave</h3>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:600px;">
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Student *</label>
    <select name="student_id" class="form-select" required>
      <option value="">-- Select --</option>
      <?php foreach ($students as $s): ?>
        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['roll_no']) ?>)</option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">From Date *</label>
      <input type="date" name="from_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">To Date *</label>
      <input type="date" name="to_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
    </div>
  </div>
  <div class="mb-3">
    <label class="form-label">Reason</label>
    <input type="text" name="reason" class="form-control">
  </div>
  <div class="alert alert-info py-2 small">This leave is recorded as approved immediately. If it runs <?= LEAVE_REDUCTION_MIN_DAYS ?>+ continuous days, a mess-fee reduction is credited automatically and attendance is marked Absent for those dates.</div>
  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
  <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>
</div>

<?php include '../includes/footer.php'; ?>
