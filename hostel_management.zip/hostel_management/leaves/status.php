<?php
require '../includes/auth.php';
require '../config/db.php';

$id = $_GET['id'] ?? null;
$action = $_GET['action'] ?? '';
$reduction = 0;

if ($id && in_array($action, ['approve','reject'])) {
    $stmt = $pdo->prepare("SELECT * FROM leaves WHERE id = ?");
    $stmt->execute([$id]);
    $leave = $stmt->fetch();

    if ($leave && $leave['status'] === 'Pending') {
        if ($action === 'approve') {
            $reduction = approve_leave($pdo, $leave);
        } else {
            $pdo->prepare("UPDATE leaves SET status='Rejected' WHERE id=?")->execute([$id]);
        }
    }
}

header("Location: list.php" . ($action === 'approve' ? "?approved=" . $reduction : ""));
exit;
