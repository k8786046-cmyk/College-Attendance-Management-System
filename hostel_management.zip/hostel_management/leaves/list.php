<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Leaves';

$leaves = $pdo->query("SELECT l.*, s.name, s.roll_no,
                        DATEDIFF(l.to_date, l.from_date) + 1 AS days
                        FROM leaves l JOIN students s ON l.student_id = s.id
                        ORDER BY l.applied_on DESC")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Leaves</h3>
  <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Record Leave</a>
</div>

<?php if (isset($_GET['approved'])): ?>
  <div class="alert alert-success py-2">
    Leave approved<?= $_GET['approved'] > 0 ? " — mess fee reduced by ₹" . number_format($_GET['approved'], 2) . " (attendance marked Absent for those days)." : " — under " . LEAVE_REDUCTION_MIN_DAYS . " days, no fee reduction applied." ?>
  </div>
<?php endif; ?>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Student</th><th>From</th><th>To</th><th>Days</th><th>Reason</th><th>Applied By</th><th>Status</th><th>Fee Reduction</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$leaves): ?>
      <tr><td colspan="10">
        <div class="empty-state">
          <i class="fa-solid fa-plane-departure"></i>
          <p>No leave records yet.</p>
          <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Record the first leave</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($leaves as $l): ?>
      <tr>
        <td><?= $l['id'] ?></td>
        <td><?= htmlspecialchars($l['name']) ?> (<?= htmlspecialchars($l['roll_no']) ?>)</td>
        <td><?= htmlspecialchars($l['from_date']) ?></td>
        <td><?= htmlspecialchars($l['to_date']) ?></td>
        <td><?= $l['days'] ?><?= $l['days'] >= LEAVE_REDUCTION_MIN_DAYS ? ' <span class="badge bg-info text-dark">7+</span>' : '' ?></td>
        <td><?= htmlspecialchars($l['reason']) ?></td>
        <td><?= htmlspecialchars($l['applied_by']) ?></td>
        <td>
          <?php $badge = ['Pending'=>'bg-warning text-dark','Approved'=>'bg-success','Rejected'=>'bg-danger'][$l['status']]; ?>
          <span class="badge <?= $badge ?>"><?= $l['status'] ?></span>
        </td>
        <td><?= $l['fee_adjusted'] && $l['reduction_amount'] > 0 ? '₹' . number_format($l['reduction_amount'],2) : '-' ?></td>
        <td>
          <?php if ($l['status'] === 'Pending'): ?>
            <a href="status.php?id=<?= $l['id'] ?>&action=approve" class="btn btn-sm btn-outline-success"><i class="fa-solid fa-check"></i> Approve</a>
            <a href="status.php?id=<?= $l['id'] ?>&action=reject" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-xmark"></i> Reject</a>
          <?php endif; ?>
          <a href="delete.php?id=<?= $l['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this leave record?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<p class="text-muted small mb-0 mt-2">Approving a leave of <?= LEAVE_REDUCTION_MIN_DAYS ?>+ continuous days automatically credits a proportional mess-fee reduction (₹<?= number_format(MESS_FEE_PER_DAY,2) ?>/day) and marks attendance Absent for those dates.</p>
</div>

<?php include '../includes/footer.php'; ?>
