<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Parent Alerts';

$alerts = $pdo->query("SELECT pa.*, s.name, s.roll_no, s.parent_phone
                        FROM parent_alerts pa JOIN students s ON pa.student_id = s.id
                        ORDER BY pa.sent_at DESC")->fetchAll();
include '../includes/header.php';
?>

<h3 class="page-title">Parent Alerts</h3>
<p class="text-muted small">No real SMS gateway is configured in this project — this log records exactly what message would be sent to each parent, and when.</p>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Student</th><th>Type</th><th>Message</th><th>Sent At</th></tr>
  </thead>
  <tbody>
    <?php if (!$alerts): ?>
      <tr><td colspan="5">
        <div class="empty-state">
          <i class="fa-solid fa-bell"></i>
          <p>No parent alerts logged yet.</p>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($alerts as $a): ?>
      <tr>
        <td><?= $a['id'] ?></td>
        <td><?= htmlspecialchars($a['name']) ?> (<?= htmlspecialchars($a['roll_no']) ?>)</td>
        <td><span class="badge bg-warning text-dark"><?= htmlspecialchars($a['alert_type']) ?></span></td>
        <td><?= htmlspecialchars($a['message']) ?></td>
        <td><?= htmlspecialchars($a['sent_at']) ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
