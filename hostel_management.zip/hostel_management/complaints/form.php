<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';

$id = $_GET['id'] ?? null;
$c = ['student_id'=>'','subject'=>'','description'=>'','date_filed'=>date('Y-m-d'),'status'=>'Open'];
$error = '';

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM complaints WHERE id = ?");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if ($found) $c = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $subject = trim($_POST['subject']);
    $description = trim($_POST['description']);
    $date_filed = $_POST['date_filed'];
    $status = $_POST['status'];

    if (!$student_id || $subject === '') {
        $error = "Student and Subject are required.";
    } else {
        if ($id) {
            $stmt = $pdo->prepare("UPDATE complaints SET student_id=?, subject=?, description=?, date_filed=?, status=? WHERE id=?");
            $stmt->execute([$student_id,$subject,$description,$date_filed,$status,$id]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO complaints (student_id, subject, description, date_filed, status) VALUES (?,?,?,?,?)");
            $stmt->execute([$student_id,$subject,$description,$date_filed,$status]);
        }
        header("Location: list.php");
        exit;
    }
}

$students = $pdo->query("SELECT id, name, roll_no FROM students ORDER BY name")->fetchAll();
$page_title = $id ? 'Edit Complaint' : 'File Complaint';
include '../includes/header.php';
?>

<h3 class="page-title"><?= $page_title ?></h3>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:600px;">
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Student *</label>
    <select name="student_id" class="form-select" required>
      <option value="">-- Select --</option>
      <?php foreach ($students as $s): ?>
        <option value="<?= $s['id'] ?>" <?= $c['student_id']==$s['id']?'selected':'' ?>><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['roll_no']) ?>)</option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="mb-3">
    <label class="form-label">Subject *</label>
    <input type="text" name="subject" class="form-control" value="<?= htmlspecialchars($c['subject']) ?>" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($c['description']) ?></textarea>
  </div>
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Date Filed</label>
      <input type="date" name="date_filed" class="form-control" value="<?= htmlspecialchars($c['date_filed']) ?>">
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <?php foreach (['Open','In Progress','Resolved'] as $st): ?>
          <option value="<?= $st ?>" <?= $c['status']===$st?'selected':'' ?>><?= $st ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
  <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>
</div>

<?php include '../includes/footer.php'; ?>
