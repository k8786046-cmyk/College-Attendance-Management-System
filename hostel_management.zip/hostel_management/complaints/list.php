<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Complaints';

$complaints = $pdo->query("SELECT c.*, s.name, s.roll_no FROM complaints c JOIN students s ON c.student_id = s.id ORDER BY c.id DESC")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Complaints</h3>
  <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> File Complaint</a>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Student</th><th>Subject</th><th>Filed On</th><th>Status</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$complaints): ?>
      <tr><td colspan="6">
        <div class="empty-state">
          <i class="fa-solid fa-triangle-exclamation"></i>
          <p>No complaints on file.</p>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($complaints as $c):
        $badge = ['Open'=>'bg-danger','In Progress'=>'bg-warning text-dark','Resolved'=>'bg-success'][$c['status']];
    ?>
      <tr>
        <td><?= $c['id'] ?></td>
        <td><?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['roll_no']) ?>)</td>
        <td><?= htmlspecialchars($c['subject']) ?></td>
        <td><?= htmlspecialchars($c['date_filed']) ?></td>
        <td><span class="badge <?= $badge ?>"><?= $c['status'] ?></span></td>
        <td>
          <a href="form.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
          <a href="delete.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this complaint?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
