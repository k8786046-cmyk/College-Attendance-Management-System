<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';

$id = $_GET['id'] ?? null;
$item = ['category'=>'','amount'=>'','period'=>'Monthly','sort_order'=>0];
$error = '';

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM fee_structure WHERE id = ?");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if ($found) $item = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = trim($_POST['category']);
    $amount = $_POST['amount'];
    $period = trim($_POST['period']);
    $sort_order = (int)$_POST['sort_order'];

    if ($category === '' || $amount === '') {
        $error = "Category and Amount are required.";
    } else {
        if ($id) {
            $stmt = $pdo->prepare("UPDATE fee_structure SET category=?, amount=?, period=?, sort_order=? WHERE id=?");
            $stmt->execute([$category, $amount, $period, $sort_order, $id]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO fee_structure (category, amount, period, sort_order) VALUES (?,?,?,?)");
            $stmt->execute([$category, $amount, $period, $sort_order]);
        }
        header("Location: list.php");
        exit;
    }
}

$page_title = $id ? 'Edit Fee Item' : 'Add Fee Item';
include '../includes/header.php';
?>

<h3 class="page-title"><?= $page_title ?></h3>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:600px;">
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Category *</label>
    <input type="text" name="category" class="form-control" value="<?= htmlspecialchars($item['category']) ?>" placeholder="e.g. Mess Fee" required>
  </div>
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Amount (₹) *</label>
      <input type="number" step="0.01" name="amount" class="form-control" value="<?= htmlspecialchars($item['amount']) ?>" required>
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">Period</label>
      <select name="period" class="form-select">
        <?php foreach (['Monthly','One-time','Yearly'] as $p): ?>
          <option value="<?= $p ?>" <?= $item['period']===$p?'selected':'' ?>><?= $p ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div class="mb-3">
    <label class="form-label">Display Order</label>
    <input type="number" name="sort_order" class="form-control" value="<?= htmlspecialchars($item['sort_order']) ?>">
  </div>
  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
  <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>
</div>

<?php include '../includes/footer.php'; ?>
