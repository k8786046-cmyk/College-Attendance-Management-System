<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Fee Structure';

$items = $pdo->query("SELECT * FROM fee_structure ORDER BY sort_order, id")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Fee Structure</h3>
  <div class="d-flex gap-2">
    <a href="../hostel_rules.php" target="_blank" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-eye"></i> View Public Page</a>
    <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Item</a>
  </div>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Category</th><th>Amount</th><th>Period</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$items): ?>
      <tr><td colspan="5">
        <div class="empty-state">
          <i class="fa-solid fa-sack-dollar"></i>
          <p>No fee structure items yet.</p>
          <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add the first item</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($items as $it): ?>
      <tr>
        <td><?= $it['id'] ?></td>
        <td><?= htmlspecialchars($it['category']) ?></td>
        <td>₹<?= number_format($it['amount'],2) ?></td>
        <td><?= htmlspecialchars($it['period']) ?></td>
        <td>
          <a href="form.php?id=<?= $it['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
          <a href="delete.php?id=<?= $it['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this item?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<p class="text-muted small mb-0 mt-2">Mess Fee here also sets the daily rate (Amount ÷ 30) used for leave-based fee reduction, unless you change <code>MESS_FEE_PER_DAY</code> in <code>config/db.php</code>.</p>
</div>

<?php include '../includes/footer.php'; ?>
