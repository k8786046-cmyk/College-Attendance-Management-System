-- ==========================================================
-- Migration: Rules & Fee Structure, Leave (with mess-fee
-- reduction), Late Entry & Parent Alerts
-- Run this ONLY if you already imported hostel_db.sql earlier
-- and don't want to lose existing data.
-- In phpMyAdmin: select your hostel_db database -> SQL tab ->
-- paste this -> Go.
-- ==========================================================

-- Parent contact details, needed to send late-entry alerts
ALTER TABLE students ADD COLUMN parent_name VARCHAR(100) NULL AFTER address;
ALTER TABLE students ADD COLUMN parent_phone VARCHAR(15) NULL AFTER parent_name;

-- ------------------------------
-- Hostel rules
-- ------------------------------
CREATE TABLE IF NOT EXISTS rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    sort_order INT NOT NULL DEFAULT 0
);

INSERT INTO rules (title, description, sort_order) VALUES
('Hostel timings', 'Main gate closes at 9:00 PM on weekdays and 10:00 PM on weekends. Late entries are logged and parents are notified.', 1),
('Visitor policy', 'Visitors are allowed only between 10:00 AM and 6:00 PM after signing the visitor register at the gate.', 2),
('Leave policy', 'Any leave of 7 days or more must be informed in advance. Mess fees are reduced proportionally for approved leave of 7+ days.', 3),
('Mess timings', 'Breakfast 7:30-9:00 AM, Lunch 12:30-2:00 PM, Dinner 7:30-9:00 PM.', 4),
('Discipline', 'Ragging, smoking, and consumption of alcohol on the premises are strictly prohibited and will lead to expulsion.', 5);

-- ------------------------------
-- Fee structure (shown to students & visitors)
-- ------------------------------
CREATE TABLE IF NOT EXISTS fee_structure (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    period VARCHAR(30) NOT NULL DEFAULT 'Monthly',
    sort_order INT NOT NULL DEFAULT 0
);

INSERT INTO fee_structure (category, amount, period, sort_order) VALUES
('Room Rent', 5000.00, 'Monthly', 1),
('Mess Fee', 3000.00, 'Monthly', 2),
('Maintenance', 500.00, 'Monthly', 3),
('Admission / Caution Deposit', 5000.00, 'One-time', 4);

-- ------------------------------
-- Leaves (drives mess-fee reduction for 7+ day leave)
-- ------------------------------
CREATE TABLE IF NOT EXISTS leaves (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    from_date DATE NOT NULL,
    to_date DATE NOT NULL,
    reason VARCHAR(255),
    applied_by ENUM('Student','Admin') NOT NULL DEFAULT 'Admin',
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    fee_adjusted TINYINT(1) NOT NULL DEFAULT 0,
    reduction_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    applied_on DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Late entry log (gate register)
-- ------------------------------
CREATE TABLE IF NOT EXISTS late_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    entry_date DATE NOT NULL,
    entry_time TIME NOT NULL,
    remarks VARCHAR(255),
    alert_sent TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Parent alerts (simulated SMS/notification log)
-- ------------------------------
CREATE TABLE IF NOT EXISTS parent_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    alert_type VARCHAR(30) NOT NULL,
    message TEXT NOT NULL,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);
