-- ==========================================================
-- Hostel Management System - Database Schema
-- Import this file in phpMyAdmin / MySQL before running the app
-- ==========================================================

CREATE DATABASE IF NOT EXISTS hostel_db;
USE hostel_db;

-- ------------------------------
-- Admin login table
-- ------------------------------
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Default login -> username: admin | password: admin123
INSERT INTO admin (username, password) VALUES
('admin', '$2b$12$J/S539iYieVxTcAxCmQzMOmBfpeC9GyqO1aeNcgZHfQuI1AqGGcNq');

-- ------------------------------
-- Rooms table
-- ------------------------------
CREATE TABLE rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_no VARCHAR(10) NOT NULL UNIQUE,
    room_type VARCHAR(20) NOT NULL,      -- Single / Double / Dormitory
    capacity INT NOT NULL,
    occupied INT NOT NULL DEFAULT 0
);

INSERT INTO rooms (room_no, room_type, capacity, occupied) VALUES
('A101', 'Double', 2, 0),
('A102', 'Double', 2, 0),
('B201', 'Single', 1, 0),
('B202', 'Dormitory', 4, 0);

-- ------------------------------
-- Students table
-- ------------------------------
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    roll_no VARCHAR(30) NOT NULL UNIQUE,
    course VARCHAR(50),
    year VARCHAR(10),
    phone VARCHAR(15),
    email VARCHAR(100),
    address VARCHAR(255),
    parent_name VARCHAR(100),
    parent_phone VARCHAR(15),
    room_id INT,
    admission_date DATE,
    password VARCHAR(255) NULL,      -- student's own login password (hashed)
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL
);

-- ------------------------------
-- Fees table
-- ------------------------------
CREATE TABLE fees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    due_date DATE,
    paid_date DATE NULL,
    status ENUM('Pending','Paid') DEFAULT 'Pending',
    remarks VARCHAR(255),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Complaints table
-- ------------------------------
CREATE TABLE complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject VARCHAR(150) NOT NULL,
    description TEXT,
    date_filed DATE NOT NULL,
    status ENUM('Open','In Progress','Resolved') DEFAULT 'Open',
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Attendance table
-- ------------------------------
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    att_date DATE NOT NULL,
    status ENUM('Present','Absent') NOT NULL,
    UNIQUE KEY unique_att (student_id, att_date),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Visitors table
-- ------------------------------
CREATE TABLE visitors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    visitor_name VARCHAR(100) NOT NULL,
    purpose VARCHAR(255),
    visit_date DATE NOT NULL,
    in_time TIME NOT NULL,
    out_time TIME NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Hostel rules (shown to students & visitors)
-- ------------------------------
CREATE TABLE rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    sort_order INT NOT NULL DEFAULT 0
);

INSERT INTO rules (title, description, sort_order) VALUES
('Hostel timings', 'Main gate closes at 9:00 PM on weekdays and 10:00 PM on weekends. Late entries are logged and parents are notified.', 1),
('Visitor policy', 'Visitors are allowed only between 10:00 AM and 6:00 PM after signing the visitor register at the gate.', 2),
('Leave policy', 'Any leave of 7 days or more must be informed in advance. Mess fees are reduced proportionally for approved leave of 7+ days.', 3),
('Mess timings', 'Breakfast 7:30-9:00 AM, Lunch 12:30-2:00 PM, Dinner 7:30-9:00 PM.', 4),
('Discipline', 'Ragging, smoking, and consumption of alcohol on the premises are strictly prohibited and will lead to expulsion.', 5);

-- ------------------------------
-- Fee structure (shown to students & visitors)
-- ------------------------------
CREATE TABLE fee_structure (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    period VARCHAR(30) NOT NULL DEFAULT 'Monthly',
    sort_order INT NOT NULL DEFAULT 0
);

INSERT INTO fee_structure (category, amount, period, sort_order) VALUES
('Room Rent', 5000.00, 'Monthly', 1),
('Mess Fee', 3000.00, 'Monthly', 2),
('Maintenance', 500.00, 'Monthly', 3),
('Admission / Caution Deposit', 5000.00, 'One-time', 4);

-- ------------------------------
-- Leaves (drives mess-fee reduction for 7+ day leave)
-- ------------------------------
CREATE TABLE leaves (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    from_date DATE NOT NULL,
    to_date DATE NOT NULL,
    reason VARCHAR(255),
    applied_by ENUM('Student','Admin') NOT NULL DEFAULT 'Admin',
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    fee_adjusted TINYINT(1) NOT NULL DEFAULT 0,
    reduction_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    applied_on DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Late entry log (gate register)
-- ------------------------------
CREATE TABLE late_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    entry_date DATE NOT NULL,
    entry_time TIME NOT NULL,
    remarks VARCHAR(255),
    alert_sent TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Parent alerts (simulated SMS/notification log)
-- ------------------------------
CREATE TABLE parent_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    alert_type VARCHAR(30) NOT NULL,
    message TEXT NOT NULL,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ------------------------------
-- Contact / enquiry messages (public "Contact Us" form on home.php)
-- ------------------------------
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(15),
    subject VARCHAR(150),
    message TEXT NOT NULL,
    status ENUM('New','Read') NOT NULL DEFAULT 'New',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------
-- Hostel admission applications (public "Apply for a Seat" form on home.php)
-- ------------------------------
CREATE TABLE hostel_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    guardian_name VARCHAR(100),
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    course_year VARCHAR(100),
    parent_phone VARCHAR(15),
    room_type ENUM('Single','Shared','Dormitory') DEFAULT 'Shared',
    message TEXT,
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
