-- ==========================================================
-- Migration: Hostel admission applications, submitted from the
-- "Apply for a Seat" form on the public home page.
-- Run this ONLY if you already imported hostel_db.sql earlier.
-- In phpMyAdmin: select your hostel_db database -> SQL tab ->
-- paste this -> Go.
-- ==========================================================

CREATE TABLE IF NOT EXISTS hostel_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    guardian_name VARCHAR(100),
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    course_year VARCHAR(100),
    parent_phone VARCHAR(15),
    room_type ENUM('Single','Shared','Dormitory') DEFAULT 'Shared',
    message TEXT,
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
