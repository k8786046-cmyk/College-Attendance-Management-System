-- ==========================================================
-- Migration: Contact / Enquiry messages from the public
-- "Contact Us" section on the home page.
-- Run this ONLY if you already imported hostel_db.sql earlier.
-- In phpMyAdmin: select your hostel_db database -> SQL tab ->
-- paste this -> Go.
-- ==========================================================

CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(15),
    subject VARCHAR(150),
    message TEXT NOT NULL,
    status ENUM('New','Read') NOT NULL DEFAULT 'New',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
