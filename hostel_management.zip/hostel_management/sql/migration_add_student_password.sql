-- ==========================================================
-- Migration: Add student self-login support
-- Run this ONLY if you already imported hostel_db.sql earlier
-- and don't want to lose existing data.
-- In phpMyAdmin: select your hostel_db database -> SQL tab ->
-- paste this -> Go.
-- ==========================================================

ALTER TABLE students ADD COLUMN password VARCHAR(255) NULL AFTER admission_date;

-- Give every existing student a default password equal to their roll number
-- (bcrypt hash of "roll_no" needs to be generated per row via the app,
--  so instead: edit each student in the admin panel once and set a
--  password there — the form now has a "Student Login Password" field).
