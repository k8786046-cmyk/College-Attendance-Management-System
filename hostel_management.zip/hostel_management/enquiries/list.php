<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Enquiries';

$messages = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Enquiries</h3>
</div>
<p class="text-muted small">Messages submitted from the "Contact Us" section of the public home page.</p>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Name</th><th>Email / Phone</th><th>Subject</th><th>Message</th><th>Received</th><th>Status</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$messages): ?>
      <tr><td colspan="8">
        <div class="empty-state">
          <i class="fa-solid fa-envelope"></i>
          <p>No enquiries yet.</p>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($messages as $m): ?>
      <tr>
        <td><?= $m['id'] ?></td>
        <td><?= htmlspecialchars($m['name']) ?></td>
        <td><?= htmlspecialchars($m['email']) ?><?= $m['phone'] ? '<br><span class="text-muted small">' . htmlspecialchars($m['phone']) . '</span>' : '' ?></td>
        <td><?= htmlspecialchars($m['subject'] ?: '-') ?></td>
        <td style="max-width:320px;"><?= nl2br(htmlspecialchars($m['message'])) ?></td>
        <td><?= htmlspecialchars($m['created_at']) ?></td>
        <td>
          <?php if ($m['status'] === 'New'): ?>
            <span class="badge bg-warning text-dark">New</span>
          <?php else: ?>
            <span class="badge bg-success">Read</span>
          <?php endif; ?>
        </td>
        <td class="text-nowrap">
          <?php if ($m['status'] === 'New'): ?>
            <a href="mark_read.php?id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-success" title="Mark as read"><i class="fa-solid fa-check"></i></a>
          <?php endif; ?>
          <a href="delete.php?id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this enquiry?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
