<?php
require '../includes/auth.php';
require '../config/db.php';
$id = $_GET['id'] ?? null;
if ($id) {
    $pdo->prepare("DELETE FROM contact_messages WHERE id = ?")->execute([$id]);
}
header("Location: list.php");
exit;
