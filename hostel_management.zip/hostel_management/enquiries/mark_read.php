<?php
require '../includes/auth.php';
require '../config/db.php';
$id = $_GET['id'] ?? null;
if ($id) {
    $pdo->prepare("UPDATE contact_messages SET status = 'Read' WHERE id = ?")->execute([$id]);
}
header("Location: list.php");
exit;
