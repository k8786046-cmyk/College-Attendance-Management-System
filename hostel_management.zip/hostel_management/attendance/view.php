<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Attendance History';

$date = $_GET['date'] ?? date('Y-m-d');

$stmt = $pdo->prepare("SELECT a.*, s.name, s.roll_no FROM attendance a JOIN students s ON a.student_id = s.id
                        WHERE a.att_date = ? ORDER BY s.name");
$stmt->execute([$date]);
$records = $stmt->fetchAll();

$present = count(array_filter($records, fn($r) => $r['status'] === 'Present'));
$absent = count($records) - $present;

include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Attendance History</h3>
  <a href="mark.php" class="btn btn-outline-primary btn-sm"><i class="fa-solid fa-calendar-check"></i> Mark Attendance</a>
</div>

<form class="row g-2 mb-3" method="GET">
  <div class="col-auto">
    <input type="date" name="date" class="form-control" value="<?= htmlspecialchars($date) ?>">
  </div>
  <div class="col-auto">
    <button class="btn btn-outline-secondary">View</button>
  </div>
</form>

<div class="row g-3 mb-3">
  <div class="col-auto"><span class="badge bg-success fs-6">Present: <?= $present ?></span></div>
  <div class="col-auto"><span class="badge bg-danger fs-6">Absent: <?= $absent ?></span></div>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead><tr><th>#</th><th>Name</th><th>Roll No</th><th>Status</th></tr></thead>
  <tbody>
    <?php if (!$records): ?>
      <tr><td colspan="4">
        <div class="empty-state">
          <i class="fa-solid fa-calendar-check"></i>
          <p>No attendance marked for <?= htmlspecialchars($date) ?>.</p>
          <a href="mark.php?date=<?= urlencode($date) ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-calendar-check"></i> Mark attendance</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($records as $i => $r): ?>
      <tr>
        <td><?= $i+1 ?></td>
        <td><?= htmlspecialchars($r['name']) ?></td>
        <td><?= htmlspecialchars($r['roll_no']) ?></td>
        <td>
          <?php if ($r['status']==='Present'): ?>
            <span class="badge bg-success">Present</span>
          <?php else: ?>
            <span class="badge bg-danger">Absent</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
