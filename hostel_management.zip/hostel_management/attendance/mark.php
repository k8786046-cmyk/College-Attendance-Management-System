<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Mark Attendance';

$date = $_GET['date'] ?? date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['att_date'];
    $statuses = $_POST['status'] ?? []; // student_id => Present/Absent

    $stmt = $pdo->prepare("INSERT INTO attendance (student_id, att_date, status) VALUES (?,?,?)
                            ON DUPLICATE KEY UPDATE status = VALUES(status)");
    foreach ($statuses as $student_id => $status) {
        $stmt->execute([$student_id, $date, $status]);
    }
    header("Location: mark.php?date=" . urlencode($date) . "&saved=1");
    exit;
}

$students = $pdo->query("SELECT id, name, roll_no FROM students ORDER BY name")->fetchAll();

$existing = [];
$stmt = $pdo->prepare("SELECT student_id, status FROM attendance WHERE att_date = ?");
$stmt->execute([$date]);
foreach ($stmt->fetchAll() as $row) {
    $existing[$row['student_id']] = $row['status'];
}

include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Mark Attendance</h3>
  <a href="view.php" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-list"></i> View History</a>
</div>

<?php if (isset($_GET['saved'])): ?>
  <div class="alert alert-success py-2">Attendance saved for <?= htmlspecialchars($date) ?>.</div>
<?php endif; ?>

<div class="card p-3">
<form method="POST">
  <div class="row g-2 mb-3">
    <div class="col-auto">
      <label class="col-form-label">Date:</label>
    </div>
    <div class="col-auto">
      <input type="date" name="att_date_picker" id="att_date_picker" class="form-control" value="<?= htmlspecialchars($date) ?>" onchange="window.location='mark.php?date='+this.value">
    </div>
  </div>
  <input type="hidden" name="att_date" value="<?= htmlspecialchars($date) ?>">

  <table class="table table-hover align-middle">
    <thead><tr><th>#</th><th>Name</th><th>Roll No</th><th>Present</th><th>Absent</th></tr></thead>
    <tbody>
      <?php if (!$students): ?>
        <tr><td colspan="5" class="text-center text-muted">No students found. Add students first.</td></tr>
      <?php endif; ?>
      <?php foreach ($students as $i => $s):
          $current = $existing[$s['id']] ?? 'Present';
      ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><?= htmlspecialchars($s['name']) ?></td>
          <td><?= htmlspecialchars($s['roll_no']) ?></td>
          <td><input type="radio" name="status[<?= $s['id'] ?>]" value="Present" <?= $current==='Present'?'checked':'' ?>></td>
          <td><input type="radio" name="status[<?= $s['id'] ?>]" value="Absent" <?= $current==='Absent'?'checked':'' ?>></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <?php if ($students): ?>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Attendance</button>
  <?php endif; ?>
</form>
</div>

<?php include '../includes/footer.php'; ?>
