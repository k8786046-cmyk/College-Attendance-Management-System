<?php
require '../includes/auth.php';
require '../config/db.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) c FROM students WHERE room_id = ?");
    $stmt->execute([$id]);
    if ($stmt->fetch()['c'] == 0) {
        $pdo->prepare("DELETE FROM rooms WHERE id = ?")->execute([$id]);
    }
}
header("Location: list.php");
exit;
