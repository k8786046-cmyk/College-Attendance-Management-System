<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';

$id = $_GET['id'] ?? null;
$room = ['room_no'=>'','room_type'=>'Double','capacity'=>2,'occupied'=>0];
$error = '';

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if ($found) $room = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_no = trim($_POST['room_no']);
    $room_type = $_POST['room_type'];
    $capacity = (int)$_POST['capacity'];

    if ($room_no === '' || $capacity < 1) {
        $error = "Room No and a valid Capacity are required.";
    } else {
        try {
            if ($id) {
                if ($capacity < $room['occupied']) {
                    $error = "Capacity cannot be less than the current occupied count (" . $room['occupied'] . ").";
                } else {
                    $stmt = $pdo->prepare("UPDATE rooms SET room_no=?, room_type=?, capacity=? WHERE id=?");
                    $stmt->execute([$room_no,$room_type,$capacity,$id]);
                    header("Location: list.php"); exit;
                }
            } else {
                $stmt = $pdo->prepare("INSERT INTO rooms (room_no, room_type, capacity, occupied) VALUES (?,?,?,0)");
                $stmt->execute([$room_no,$room_type,$capacity]);
                header("Location: list.php"); exit;
            }
        } catch (Exception $e) {
            $error = "Room No already exists.";
        }
    }
}

$page_title = $id ? 'Edit Room' : 'Add Room';
include '../includes/header.php';
?>

<h3 class="page-title"><?= $page_title ?></h3>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:500px;">
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Room No *</label>
    <input type="text" name="room_no" class="form-control" value="<?= htmlspecialchars($room['room_no']) ?>" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Type</label>
    <select name="room_type" class="form-select">
      <?php foreach (['Single','Double','Dormitory'] as $t): ?>
        <option value="<?= $t ?>" <?= $room['room_type']===$t?'selected':'' ?>><?= $t ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="mb-3">
    <label class="form-label">Capacity *</label>
    <input type="number" name="capacity" min="1" class="form-control" value="<?= htmlspecialchars($room['capacity']) ?>" required>
  </div>
  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
  <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>
</div>

<?php include '../includes/footer.php'; ?>
