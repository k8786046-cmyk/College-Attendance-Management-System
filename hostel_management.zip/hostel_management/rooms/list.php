<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Rooms';

$rooms = $pdo->query("SELECT * FROM rooms ORDER BY room_no")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Rooms</h3>
  <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Room</a>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Room No</th><th>Type</th><th>Capacity</th><th>Occupied</th><th>Vacant</th><th>Status</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$rooms): ?>
      <tr><td colspan="8">
        <div class="empty-state">
          <i class="fa-solid fa-door-open"></i>
          <p>No rooms set up yet.</p>
          <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add the first room</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($rooms as $r):
        $vacant = $r['capacity'] - $r['occupied'];
    ?>
      <tr>
        <td><?= $r['id'] ?></td>
        <td><?= htmlspecialchars($r['room_no']) ?></td>
        <td><?= htmlspecialchars($r['room_type']) ?></td>
        <td><?= $r['capacity'] ?></td>
        <td><?= $r['occupied'] ?></td>
        <td><?= $vacant ?></td>
        <td>
          <?php if ($vacant <= 0): ?>
            <span class="badge bg-danger">Full</span>
          <?php else: ?>
            <span class="badge bg-success">Available</span>
          <?php endif; ?>
        </td>
        <td>
          <a href="form.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
          <a href="delete.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this room?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
