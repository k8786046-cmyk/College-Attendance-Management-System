<?php
// ---- Database connection settings ----
// Change these if your MySQL setup is different (e.g. XAMPP default is user 'root', pass '')
$host   = 'localhost';
$dbname = 'hostel_db';
$user   = 'root';
$pass   = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// ---- App settings ----
// Per-day mess fee used to work out leave-based fee reduction.
if (!defined('MESS_FEE_PER_DAY')) define('MESS_FEE_PER_DAY', 100.00);
// A leave must run at least this many continuous days before mess fee is reduced.
if (!defined('LEAVE_REDUCTION_MIN_DAYS')) define('LEAVE_REDUCTION_MIN_DAYS', 7);
// Gate entries after this time are logged as "late" and trigger a parent alert.
if (!defined('CURFEW_TIME')) define('CURFEW_TIME', '21:00:00');

/**
 * Approve a leave: mark attendance Absent for every day of the leave,
 * and if it runs LEAVE_REDUCTION_MIN_DAYS or more, credit a proportional
 * mess-fee reduction as a fee record. Safe to call only once per leave
 * (checks/sets fee_adjusted).
 */
function approve_leave(PDO $pdo, array $leave): float {
    $reduction = 0.0;

    $from = new DateTime($leave['from_date']);
    $to   = new DateTime($leave['to_date']);
    $days = $to->diff($from)->days + 1;

    // Mark attendance Absent for each day of the leave
    $attStmt = $pdo->prepare("INSERT INTO attendance (student_id, att_date, status) VALUES (?,?,'Absent')
                               ON DUPLICATE KEY UPDATE status = 'Absent'");
    $cursor = clone $from;
    while ($cursor <= $to) {
        $attStmt->execute([$leave['student_id'], $cursor->format('Y-m-d')]);
        $cursor->modify('+1 day');
    }

    // Proportional mess-fee reduction for 7+ continuous days of leave
    if ($days >= LEAVE_REDUCTION_MIN_DAYS && !$leave['fee_adjusted']) {
        $reduction = round($days * MESS_FEE_PER_DAY, 2);
        $remarks = "Mess fee reduction — {$days} day(s) leave ({$leave['from_date']} to {$leave['to_date']})";
        $pdo->prepare("INSERT INTO fees (student_id, amount, due_date, paid_date, status, remarks) VALUES (?,?,?,?, 'Paid', ?)")
            ->execute([$leave['student_id'], -$reduction, $leave['to_date'], date('Y-m-d'), $remarks]);
    }

    $pdo->prepare("UPDATE leaves SET status='Approved', fee_adjusted=1, reduction_amount=? WHERE id=?")
        ->execute([$reduction, $leave['id']]);

    return $reduction;
}

/**
 * Log a simulated parent alert (no real SMS gateway configured — this
 * records the message so the admin can see exactly what would be sent).
 */
function send_parent_alert(PDO $pdo, int $student_id, string $type, string $message): void {
    $pdo->prepare("INSERT INTO parent_alerts (student_id, alert_type, message) VALUES (?,?,?)")
        ->execute([$student_id, $type, $message]);
}
