<?php
require '../includes/auth.php';
require '../config/db.php';

// Only accept POST so a stray link/prefetch can never change a status
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: list.php");
    exit;
}

$id     = (int) ($_POST['id'] ?? 0);
$status = $_POST['status'] ?? '';
$back   = $_POST['back'] ?? '';

$flash = 'error';
if ($id > 0 && in_array($status, ['Approved', 'Rejected'], true)) {
    $stmt = $pdo->prepare("UPDATE hostel_applications SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);
    $flash = strtolower($status); // approved / rejected
}

$params = ['msg' => $flash];
if (in_array($back, ['Pending', 'Approved', 'Rejected'], true)) {
    $params['status'] = $back;
}
header("Location: list.php?" . http_build_query($params));
exit;
