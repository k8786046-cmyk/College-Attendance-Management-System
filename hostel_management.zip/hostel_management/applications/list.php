<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Admissions';

$statusFilter = $_GET['status'] ?? 'All';
$sql = "SELECT * FROM hostel_applications";
if (in_array($statusFilter, ['Pending', 'Approved', 'Rejected'], true)) {
    $sql .= " WHERE status = " . $pdo->quote($statusFilter);
}
$sql .= " ORDER BY created_at DESC";
$applications = $pdo->query($sql)->fetchAll();

$pendingCount = $pdo->query("SELECT COUNT(*) c FROM hostel_applications WHERE status='Pending'")->fetch()['c'];

include '../includes/header.php';
?>

<?php $msg = $_GET['msg'] ?? ''; ?>
<?php if ($msg === 'approved'): ?>
  <div class="alert alert-success py-2">Application approved.</div>
<?php elseif ($msg === 'rejected'): ?>
  <div class="alert alert-danger py-2">Application rejected.</div>
<?php elseif ($msg === 'error'): ?>
  <div class="alert alert-warning py-2">Could not update the application.</div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <h3 class="page-title">Hostel Admissions</h3>
  <div class="btn-group">
    <a href="list.php" class="btn btn-sm <?= $statusFilter === 'All' ? 'btn-primary' : 'btn-outline-primary' ?>">All</a>
    <a href="list.php?status=Pending" class="btn btn-sm <?= $statusFilter === 'Pending' ? 'btn-primary' : 'btn-outline-primary' ?>">Pending (<?= $pendingCount ?>)</a>
    <a href="list.php?status=Approved" class="btn btn-sm <?= $statusFilter === 'Approved' ? 'btn-primary' : 'btn-outline-primary' ?>">Approved</a>
    <a href="list.php?status=Rejected" class="btn btn-sm <?= $statusFilter === 'Rejected' ? 'btn-primary' : 'btn-outline-primary' ?>">Rejected</a>
  </div>
</div>
<p class="text-muted small">New seat requests submitted from the "Apply for a Seat" form on the public home page. Approve a request, then add the resident from <a href="../students/list.php">Students</a> once a room is assigned.</p>

<div class="card p-3">
<div class="table-responsive">
<table class="table table-hover align-middle">
  <thead>
    <tr>
      <th>#</th><th>Applicant</th><th>Contact</th><th>Course / Year</th>
      <th>Parent Phone</th><th>Room Pref.</th><th>Message</th><th>Applied On</th>
      <th>Status</th><th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php if (!$applications): ?>
      <tr><td colspan="10">
        <div class="empty-state">
          <i class="fa-solid fa-house-circle-check"></i>
          <p>No admission applications<?= $statusFilter !== 'All' ? ' with status "' . htmlspecialchars($statusFilter) . '"' : '' ?> yet.</p>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($applications as $a): ?>
      <tr>
        <td><?= $a['id'] ?></td>
        <td>
          <?= htmlspecialchars($a['full_name']) ?>
          <?php if ($a['guardian_name']): ?><br><span class="text-muted small">Guardian: <?= htmlspecialchars($a['guardian_name']) ?></span><?php endif; ?>
        </td>
        <td><?= htmlspecialchars($a['phone']) ?><?= $a['email'] ? '<br><span class="text-muted small">' . htmlspecialchars($a['email']) . '</span>' : '' ?></td>
        <td><?= htmlspecialchars($a['course_year'] ?: '-') ?></td>
        <td><?= htmlspecialchars($a['parent_phone'] ?: '-') ?></td>
        <td><span class="badge bg-secondary bg-opacity-10 text-dark border"><?= htmlspecialchars($a['room_type']) ?></span></td>
        <td style="max-width:260px;"><?= $a['message'] ? nl2br(htmlspecialchars($a['message'])) : '<span class="text-muted">-</span>' ?></td>
        <td><?= htmlspecialchars($a['created_at']) ?></td>
        <td>
          <?php if ($a['status'] === 'Pending'): ?>
            <span class="badge bg-warning text-dark">Pending</span>
          <?php elseif ($a['status'] === 'Approved'): ?>
            <span class="badge bg-success">Approved</span>
          <?php else: ?>
            <span class="badge bg-danger">Rejected</span>
          <?php endif; ?>
        </td>
        <td class="text-nowrap">
          <?php if ($a['status'] !== 'Approved'): ?>
            <form method="post" action="update_status.php" class="d-inline">
              <input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
              <input type="hidden" name="status" value="Approved">
              <input type="hidden" name="back" value="<?= $statusFilter !== 'All' ? htmlspecialchars($statusFilter) : '' ?>">
              <button type="submit" class="btn btn-sm btn-success">Approve</button>
            </form>
          <?php endif; ?>
          <?php if ($a['status'] !== 'Rejected'): ?>
            <form method="post" action="update_status.php" class="d-inline" onsubmit="return confirm('Reject this application?');">
              <input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
              <input type="hidden" name="status" value="Rejected">
              <input type="hidden" name="back" value="<?= $statusFilter !== 'All' ? htmlspecialchars($statusFilter) : '' ?>">
              <button type="submit" class="btn btn-sm btn-outline-danger">Reject</button>
            </form>
          <?php endif; ?>
          <a href="delete.php?id=<?= $a['id'] ?>" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Delete this application?');" title="Delete"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>

<?php include '../includes/footer.php'; ?>
