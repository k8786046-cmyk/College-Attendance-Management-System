<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';

$id = $_GET['id'] ?? null;
$rule = ['title'=>'','description'=>'','sort_order'=>0];
$error = '';

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM rules WHERE id = ?");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if ($found) $rule = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $sort_order = (int)$_POST['sort_order'];

    if ($title === '') {
        $error = "Title is required.";
    } else {
        if ($id) {
            $stmt = $pdo->prepare("UPDATE rules SET title=?, description=?, sort_order=? WHERE id=?");
            $stmt->execute([$title, $description, $sort_order, $id]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO rules (title, description, sort_order) VALUES (?,?,?)");
            $stmt->execute([$title, $description, $sort_order]);
        }
        header("Location: list.php");
        exit;
    }
}

$page_title = $id ? 'Edit Rule' : 'Add Rule';
include '../includes/header.php';
?>

<h3 class="page-title"><?= $page_title ?></h3>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:600px;">
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Title *</label>
    <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($rule['title']) ?>" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($rule['description']) ?></textarea>
  </div>
  <div class="mb-3">
    <label class="form-label">Display Order</label>
    <input type="number" name="sort_order" class="form-control" value="<?= htmlspecialchars($rule['sort_order']) ?>">
  </div>
  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
  <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>
</div>

<?php include '../includes/footer.php'; ?>
