<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Hostel Rules';

$rules = $pdo->query("SELECT * FROM rules ORDER BY sort_order, id")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Hostel Rules</h3>
  <div class="d-flex gap-2">
    <a href="../hostel_rules.php" target="_blank" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-eye"></i> View Public Page</a>
    <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Rule</a>
  </div>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Title</th><th>Description</th><th>Order</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$rules): ?>
      <tr><td colspan="5">
        <div class="empty-state">
          <i class="fa-solid fa-book"></i>
          <p>No rules added yet.</p>
          <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add the first rule</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($rules as $r): ?>
      <tr>
        <td><?= $r['id'] ?></td>
        <td><?= htmlspecialchars($r['title']) ?></td>
        <td><?= htmlspecialchars($r['description']) ?></td>
        <td><?= $r['sort_order'] ?></td>
        <td>
          <a href="form.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
          <a href="delete.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this rule?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
