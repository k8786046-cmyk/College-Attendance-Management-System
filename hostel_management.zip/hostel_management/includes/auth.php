<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: " . (strpos($_SERVER['PHP_SELF'], '/students/') || strpos($_SERVER['PHP_SELF'], '/rooms/') ||
        strpos($_SERVER['PHP_SELF'], '/fees/') || strpos($_SERVER['PHP_SELF'], '/complaints/') ||
        strpos($_SERVER['PHP_SELF'], '/attendance/') || strpos($_SERVER['PHP_SELF'], '/visitors/') ||
        strpos($_SERVER['PHP_SELF'], '/leaves/') || strpos($_SERVER['PHP_SELF'], '/late/') ||
        strpos($_SERVER['PHP_SELF'], '/alerts/') || strpos($_SERVER['PHP_SELF'], '/rules/') ||
        strpos($_SERVER['PHP_SELF'], '/fee_structure/') ||
        strpos($_SERVER['PHP_SELF'], '/applications/') || strpos($_SERVER['PHP_SELF'], '/enquiries/')
        ? '../login.php' : 'login.php'));
    exit;
}
