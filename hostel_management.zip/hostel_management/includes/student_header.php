<?php
$__file = basename($_SERVER['PHP_SELF']);
function snav_active($file) {
    global $__file;
    return $__file === $file ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - ' : '' ?>Hostel Management System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="<?= $base ?>assets/img/favicon.svg" rel="icon" type="image/svg+xml">
<link href="<?= $base ?>assets/css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-dark hms-navbar px-3">
  <div class="d-flex align-items-center gap-3">
    <button type="button" class="sidebar-toggle-btn" id="sidebarToggle" aria-label="Toggle menu">
      <i class="fa-solid fa-bars"></i>
    </button>
    <span class="brand-mark">
      <svg class="brand-crest" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
        <path d="M16 2 L28 7 V16 C28 23 22.5 27.5 16 30 C9.5 27.5 4 23 4 16 V7 Z" fill-opacity="0.15"/>
        <path d="M16 2 L28 7 V16 C28 23 22.5 27.5 16 30 C9.5 27.5 4 23 4 16 V7 Z" fill="none" stroke="#C9A227" stroke-width="1.6"/>
        <path d="M11 19 V13 L16 10 L21 13 V19 H17.5 V15.5 H14.5 V19 Z" fill="#C9A227"/>
      </svg>
      Hostel Management System
      <span class="portal-tag">Student Portal</span>
    </span>
  </div>
  <div class="d-flex align-items-center text-white">
    <span class="me-3 d-none d-sm-inline"><i class="fa-solid fa-user-graduate"></i> <?= htmlspecialchars($_SESSION['student_name'] ?? 'Student') ?></span>
    <a href="<?= $base ?>student_logout.php" class="btn btn-sm btn-outline-light"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
  </div>
</nav>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="d-flex">
  <div class="hms-sidebar p-0" id="hmsSidebar">
    <a href="<?= $base ?>student/dashboard.php" class="sidebar-link <?= snav_active('dashboard.php') ?>"><i class="fa-solid fa-gauge"></i> My Dashboard</a>
    <a href="<?= $base ?>student/fees.php" class="sidebar-link <?= snav_active('fees.php') ?>"><i class="fa-solid fa-money-bill"></i> My Fees</a>
    <a href="<?= $base ?>student/complaints.php" class="sidebar-link <?= snav_active('complaints.php') ?>"><i class="fa-solid fa-triangle-exclamation"></i> My Complaints</a>
    <a href="<?= $base ?>student/attendance.php" class="sidebar-link <?= snav_active('attendance.php') ?>"><i class="fa-solid fa-calendar-check"></i> My Attendance</a>
    <a href="<?= $base ?>student/leaves.php" class="sidebar-link <?= snav_active('leaves.php') ?>"><i class="fa-solid fa-plane-departure"></i> My Leaves</a>
    <a href="<?= $base ?>hostel_rules.php" class="sidebar-link" target="_blank"><i class="fa-solid fa-book"></i> Hostel Rules</a>
  </div>
  <div class="hms-content p-4">
