<?php
$__dir  = basename(dirname($_SERVER['PHP_SELF']));
$__file = basename($_SERVER['PHP_SELF']);
function nav_active($matchDir) {
    global $__dir, $__file;
    if ($matchDir === '') return ($__file === 'index.php') ? 'active' : '';
    return $__dir === $matchDir ? 'active' : '';
}
$__newEnquiries = 0;
$__pendingApplications = 0;
if (isset($pdo)) {
    try {
        $__newEnquiries = (int) $pdo->query("SELECT COUNT(*) c FROM contact_messages WHERE status = 'New'")->fetch()['c'];
    } catch (Exception $e) {
        $__newEnquiries = 0;
    }
    try {
        $__pendingApplications = (int) $pdo->query("SELECT COUNT(*) c FROM hostel_applications WHERE status = 'Pending'")->fetch()['c'];
    } catch (Exception $e) {
        $__pendingApplications = 0;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - ' : '' ?>Hostel Management System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="<?= $base ?>assets/img/favicon.svg" rel="icon" type="image/svg+xml">
<link href="<?= $base ?>assets/css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-dark hms-navbar px-3">
  <div class="d-flex align-items-center gap-3">
    <button type="button" class="sidebar-toggle-btn" id="sidebarToggle" aria-label="Toggle menu">
      <i class="fa-solid fa-bars"></i>
    </button>
    <span class="brand-mark">
      <svg class="brand-crest" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
        <path d="M16 2 L28 7 V16 C28 23 22.5 27.5 16 30 C9.5 27.5 4 23 4 16 V7 Z" fill-opacity="0.15"/>
        <path d="M16 2 L28 7 V16 C28 23 22.5 27.5 16 30 C9.5 27.5 4 23 4 16 V7 Z" fill="none" stroke="#C9A227" stroke-width="1.6"/>
        <path d="M11 19 V13 L16 10 L21 13 V19 H17.5 V15.5 H14.5 V19 Z" fill="#C9A227"/>
      </svg>
      Hostel Management System
      <span class="portal-tag">Admin Portal</span>
    </span>
  </div>
  <div class="d-flex align-items-center text-white">
    <span class="me-3 d-none d-sm-inline"><i class="fa-solid fa-user-shield"></i> <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></span>
    <a href="<?= $base ?>logout.php" class="btn btn-sm btn-outline-light"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
  </div>
</nav>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="d-flex">
  <div class="hms-sidebar p-0" id="hmsSidebar">
    <div class="sidebar-section-label">Overview</div>
    <a href="<?= $base ?>index.php" class="sidebar-link <?= nav_active('') ?>"><i class="fa-solid fa-gauge"></i> Dashboard</a>

    <div class="sidebar-section-label">Residents</div>
    <a href="<?= $base ?>applications/list.php" class="sidebar-link <?= nav_active('applications') ?>"><i class="fa-solid fa-house-circle-check"></i> Admissions<?= $__pendingApplications > 0 ? ' <span class="badge bg-warning text-dark ms-1">' . $__pendingApplications . '</span>' : '' ?></a>
    <a href="<?= $base ?>students/list.php" class="sidebar-link <?= nav_active('students') ?>"><i class="fa-solid fa-user-graduate"></i> Students</a>
    <a href="<?= $base ?>rooms/list.php" class="sidebar-link <?= nav_active('rooms') ?>"><i class="fa-solid fa-door-open"></i> Rooms</a>
    <a href="<?= $base ?>attendance/mark.php" class="sidebar-link <?= nav_active('attendance') ?>"><i class="fa-solid fa-calendar-check"></i> Attendance</a>
    <a href="<?= $base ?>leaves/list.php" class="sidebar-link <?= nav_active('leaves') ?>"><i class="fa-solid fa-plane-departure"></i> Leaves</a>
    <a href="<?= $base ?>complaints/list.php" class="sidebar-link <?= nav_active('complaints') ?>"><i class="fa-solid fa-triangle-exclamation"></i> Complaints</a>

    <div class="sidebar-section-label">Finance</div>
    <a href="<?= $base ?>fees/list.php" class="sidebar-link <?= nav_active('fees') ?>"><i class="fa-solid fa-money-bill"></i> Fees</a>
    <a href="<?= $base ?>fee_structure/list.php" class="sidebar-link <?= nav_active('fee_structure') ?>"><i class="fa-solid fa-sack-dollar"></i> Fee Structure</a>

    <div class="sidebar-section-label">Safety &amp; Access</div>
    <a href="<?= $base ?>visitors/list.php" class="sidebar-link <?= nav_active('visitors') ?>"><i class="fa-solid fa-address-book"></i> Visitors</a>
    <a href="<?= $base ?>late/list.php" class="sidebar-link <?= nav_active('late') ?>"><i class="fa-solid fa-clock"></i> Late Entry</a>
    <a href="<?= $base ?>alerts/list.php" class="sidebar-link <?= nav_active('alerts') ?>"><i class="fa-solid fa-bell"></i> Parent Alerts</a>
    <a href="<?= $base ?>rules/list.php" class="sidebar-link <?= nav_active('rules') ?>"><i class="fa-solid fa-book"></i> Rules</a>

    <div class="sidebar-section-label">Communication</div>
    <a href="<?= $base ?>enquiries/list.php" class="sidebar-link <?= nav_active('enquiries') ?>"><i class="fa-solid fa-envelope"></i> Enquiries<?= $__newEnquiries > 0 ? ' <span class="badge bg-warning text-dark ms-1">' . $__newEnquiries . '</span>' : '' ?></a>
  </div>
  <div class="hms-content p-4">
