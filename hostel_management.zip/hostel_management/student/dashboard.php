<?php
require '../includes/student_auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'My Dashboard';

$sid = $_SESSION['student_id'];

$stmt = $pdo->prepare("SELECT s.*, r.room_no, r.room_type FROM students s LEFT JOIN rooms r ON s.room_id = r.id WHERE s.id = ?");
$stmt->execute([$sid]);
$me = $stmt->fetch();

$pendingFees = $pdo->prepare("SELECT COUNT(*) c FROM fees WHERE student_id = ? AND status = 'Pending'");
$pendingFees->execute([$sid]);
$pendingFees = $pendingFees->fetch()['c'];

$openComplaints = $pdo->prepare("SELECT COUNT(*) c FROM complaints WHERE student_id = ? AND status != 'Resolved'");
$openComplaints->execute([$sid]);
$openComplaints = $openComplaints->fetch()['c'];

$presentDays = $pdo->prepare("SELECT COUNT(*) c FROM attendance WHERE student_id = ? AND status = 'Present'");
$presentDays->execute([$sid]);
$presentDays = $presentDays->fetch()['c'];

$totalPaid = $pdo->prepare("SELECT COALESCE(SUM(amount),0) t FROM fees WHERE student_id = ? AND status='Paid'");
$totalPaid->execute([$sid]);
$totalPaid = $totalPaid->fetch()['t'];

$totalPendingAmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) t FROM fees WHERE student_id = ? AND status='Pending'");
$totalPendingAmt->execute([$sid]);
$totalPendingAmt = $totalPendingAmt->fetch()['t'];

$daysInHostel = null;
if (!empty($me['admission_date'])) {
    $adm = new DateTime($me['admission_date']);
    $today = new DateTime();
    if ($adm <= $today) $daysInHostel = $adm->diff($today)->days + 1;
}

include '../includes/student_header.php';
?>

<h3 class="page-title">Welcome, <?= htmlspecialchars($me['name']) ?></h3>

<div class="stat-strip">
  <div class="stat-block">
    <i class="fa-solid fa-door-open stat-icon"></i>
    <div class="stat-num" style="font-size:1.4rem;"><?= $me['room_no'] ? htmlspecialchars($me['room_no']) : 'Unassigned' ?></div>
    <div class="stat-label">My Room</div>
  </div>
  <div class="stat-block">
    <i class="fa-solid fa-calendar-day stat-icon"></i>
    <div class="stat-num"><?= $daysInHostel !== null ? $daysInHostel : '-' ?></div>
    <div class="stat-label">Days in Hostel</div>
  </div>
  <div class="stat-block <?= $pendingFees > 0 ? 'flag' : '' ?>">
    <i class="fa-solid fa-money-bill stat-icon"></i>
    <div class="stat-num" style="font-size:1.2rem;">₹<?= number_format($totalPendingAmt,2) ?></div>
    <div class="stat-label">Fees Pending</div>
  </div>
  <div class="stat-block">
    <i class="fa-solid fa-money-bill-wave stat-icon"></i>
    <div class="stat-num" style="font-size:1.2rem;">₹<?= number_format($totalPaid,2) ?></div>
    <div class="stat-label">Fees Paid</div>
  </div>
  <div class="stat-block <?= $openComplaints > 0 ? 'flag' : '' ?>">
    <i class="fa-solid fa-triangle-exclamation stat-icon"></i>
    <div class="stat-num"><?= $openComplaints ?></div>
    <div class="stat-label">Open Complaints</div>
  </div>
  <div class="stat-block">
    <i class="fa-solid fa-calendar-check stat-icon"></i>
    <div class="stat-num"><?= $presentDays ?></div>
    <div class="stat-label">Days Present</div>
  </div>
</div>

<div class="card p-3">
  <div class="panel-title">My Details</div>
  <table class="table mb-0">
    <tr><th style="width:180px;">Roll No</th><td><?= htmlspecialchars($me['roll_no']) ?></td></tr>
    <tr><th>Course</th><td><?= htmlspecialchars($me['course']) ?></td></tr>
    <tr><th>Year</th><td><?= htmlspecialchars($me['year']) ?></td></tr>
    <tr><th>Phone</th><td><?= htmlspecialchars($me['phone']) ?></td></tr>
    <tr><th>Email</th><td><?= htmlspecialchars($me['email']) ?></td></tr>
    <tr><th>Room</th><td><?= $me['room_no'] ? htmlspecialchars($me['room_no'] . ' (' . $me['room_type'] . ')') : 'Unassigned' ?></td></tr>
    <tr><th>Admission Date</th><td><?= htmlspecialchars($me['admission_date']) ?></td></tr>
  </table>
</div>

<?php include '../includes/footer.php'; ?>
