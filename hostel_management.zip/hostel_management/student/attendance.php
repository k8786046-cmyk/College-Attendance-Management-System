<?php
require '../includes/student_auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'My Attendance';

$sid = $_SESSION['student_id'];
$stmt = $pdo->prepare("SELECT * FROM attendance WHERE student_id = ? ORDER BY att_date DESC LIMIT 60");
$stmt->execute([$sid]);
$records = $stmt->fetchAll();

$totalP = $pdo->prepare("SELECT COUNT(*) c FROM attendance WHERE student_id = ? AND status='Present'");
$totalP->execute([$sid]);
$totalP = $totalP->fetch()['c'];

$totalA = $pdo->prepare("SELECT COUNT(*) c FROM attendance WHERE student_id = ? AND status='Absent'");
$totalA->execute([$sid]);
$totalA = $totalA->fetch()['c'];

include '../includes/student_header.php';
?>

<h3 class="page-title">My Attendance</h3>

<div class="row g-3 mb-3">
  <div class="col-auto"><span class="badge bg-success fs-6">Present: <?= $totalP ?></span></div>
  <div class="col-auto"><span class="badge bg-danger fs-6">Absent: <?= $totalA ?></span></div>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead><tr><th>#</th><th>Date</th><th>Status</th></tr></thead>
  <tbody>
    <?php if (!$records): ?>
      <tr><td colspan="3">
        <div class="empty-state">
          <i class="fa-solid fa-calendar-check"></i>
          <p>No attendance records yet.</p>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($records as $i => $r): ?>
      <tr>
        <td><?= $i+1 ?></td>
        <td><?= htmlspecialchars($r['att_date']) ?></td>
        <td>
          <?php if ($r['status']==='Present'): ?>
            <span class="badge bg-success">Present</span>
          <?php else: ?>
            <span class="badge bg-danger">Absent</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
