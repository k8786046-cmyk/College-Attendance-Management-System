<?php
require '../includes/student_auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'My Leaves';

$sid = $_SESSION['student_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $reason = trim($_POST['reason']);

    if (!$from_date || !$to_date) {
        $error = "From Date and To Date are required.";
    } elseif ($to_date < $from_date) {
        $error = "To Date cannot be before From Date.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO leaves (student_id, from_date, to_date, reason, applied_by, status) VALUES (?,?,?,?, 'Student', 'Pending')");
        $stmt->execute([$sid, $from_date, $to_date, $reason]);
        header("Location: leaves.php?applied=1");
        exit;
    }
}

$stmt = $pdo->prepare("SELECT l.*, DATEDIFF(l.to_date, l.from_date) + 1 AS days
                        FROM leaves l WHERE l.student_id = ? ORDER BY l.applied_on DESC");
$stmt->execute([$sid]);
$leaves = $stmt->fetchAll();

include '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">My Leaves</h3>
  <button class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#newLeaveForm">
    <i class="fa-solid fa-plus"></i> Apply for Leave
  </button>
</div>

<?php if (isset($_GET['applied'])): ?>
  <div class="alert alert-success py-2">Leave request submitted. It will show as Pending until the warden approves it.</div>
<?php endif; ?>

<div class="collapse mb-3" id="newLeaveForm">
  <div class="card p-3">
    <?php if ($error): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">From Date *</label>
          <input type="date" name="from_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">To Date *</label>
          <input type="date" name="to_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Reason</label>
        <input type="text" name="reason" class="form-control">
      </div>
      <div class="form-text mb-3">Leave of 7 or more continuous days, once approved, automatically reduces your mess fee proportionally.</div>
      <button type="submit" class="btn btn-primary btn-sm">Submit Request</button>
    </form>
  </div>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead><tr><th>#</th><th>From</th><th>To</th><th>Days</th><th>Reason</th><th>Status</th><th>Fee Reduction</th></tr></thead>
  <tbody>
    <?php if (!$leaves): ?>
      <tr><td colspan="7">
        <div class="empty-state">
          <i class="fa-solid fa-plane-departure"></i>
          <p>No leave requests yet.</p>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($leaves as $l): ?>
      <tr>
        <td><?= $l['id'] ?></td>
        <td><?= htmlspecialchars($l['from_date']) ?></td>
        <td><?= htmlspecialchars($l['to_date']) ?></td>
        <td><?= $l['days'] ?></td>
        <td><?= htmlspecialchars($l['reason']) ?></td>
        <td>
          <?php $badge = ['Pending'=>'bg-warning text-dark','Approved'=>'bg-success','Rejected'=>'bg-danger'][$l['status']]; ?>
          <span class="badge <?= $badge ?>"><?= $l['status'] ?></span>
        </td>
        <td><?= $l['fee_adjusted'] && $l['reduction_amount'] > 0 ? '₹' . number_format($l['reduction_amount'],2) : '-' ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
