<?php
require '../includes/student_auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'My Complaints';

$sid = $_SESSION['student_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject']);
    $description = trim($_POST['description']);

    if ($subject === '') {
        $error = "Subject is required.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO complaints (student_id, subject, description, date_filed, status) VALUES (?,?,?,?,'Open')");
        $stmt->execute([$sid, $subject, $description, date('Y-m-d')]);
        header("Location: complaints.php");
        exit;
    }
}

$stmt = $pdo->prepare("SELECT * FROM complaints WHERE student_id = ? ORDER BY id DESC");
$stmt->execute([$sid]);
$complaints = $stmt->fetchAll();

include '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">My Complaints</h3>
  <button class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#newComplaintForm">
    <i class="fa-solid fa-plus"></i> File New Complaint
  </button>
</div>

<div class="collapse mb-3" id="newComplaintForm">
  <div class="card p-3">
    <?php if ($error): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Subject *</label>
        <input type="text" name="subject" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" rows="3"></textarea>
      </div>
      <button type="submit" class="btn btn-primary btn-sm">Submit Complaint</button>
    </form>
  </div>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead><tr><th>#</th><th>Subject</th><th>Filed On</th><th>Status</th></tr></thead>
  <tbody>
    <?php if (!$complaints): ?>
      <tr><td colspan="4">
        <div class="empty-state">
          <i class="fa-solid fa-triangle-exclamation"></i>
          <p>No complaints filed yet.</p>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($complaints as $c):
        $badge = ['Open'=>'bg-danger','In Progress'=>'bg-warning text-dark','Resolved'=>'bg-success'][$c['status']];
    ?>
      <tr>
        <td><?= $c['id'] ?></td>
        <td><?= htmlspecialchars($c['subject']) ?></td>
        <td><?= htmlspecialchars($c['date_filed']) ?></td>
        <td><span class="badge <?= $badge ?>"><?= $c['status'] ?></span></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
