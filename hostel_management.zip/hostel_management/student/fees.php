<?php
require '../includes/student_auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'My Fees';

$sid = $_SESSION['student_id'];
$stmt = $pdo->prepare("SELECT * FROM fees WHERE student_id = ? ORDER BY due_date DESC");
$stmt->execute([$sid]);
$fees = $stmt->fetchAll();

$paid = $pdo->prepare("SELECT COALESCE(SUM(amount),0) t FROM fees WHERE student_id = ? AND status='Paid'");
$paid->execute([$sid]);
$totalPaid = $paid->fetch()['t'];

$pending = $pdo->prepare("SELECT COALESCE(SUM(amount),0) t FROM fees WHERE student_id = ? AND status='Pending'");
$pending->execute([$sid]);
$totalPending = $pending->fetch()['t'];

include '../includes/student_header.php';
?>

<h3 class="page-title">My Fees</h3>

<div class="row g-3 mb-3">
  <div class="col-auto"><span class="badge bg-dark fs-6">Total Paid: ₹<?= number_format($totalPaid,2) ?></span></div>
  <div class="col-auto"><span class="badge <?= $totalPending>0?'bg-warning text-dark':'bg-success' ?> fs-6">Total Pending: ₹<?= number_format($totalPending,2) ?></span></div>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead><tr><th>#</th><th>Amount</th><th>Due Date</th><th>Paid Date</th><th>Status</th><th>Remarks</th></tr></thead>
  <tbody>
    <?php if (!$fees): ?>
      <tr><td colspan="6">
        <div class="empty-state">
          <i class="fa-solid fa-money-bill"></i>
          <p>No fee records yet — nothing pending.</p>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($fees as $f): $isCredit = $f['amount'] < 0; ?>
      <tr>
        <td><?= $f['id'] ?></td>
        <td class="<?= $isCredit ? 'text-success' : '' ?>"><?= $isCredit ? '− ₹' . number_format(abs($f['amount']),2) . ' <span class="badge bg-success">Credit</span>' : '₹' . number_format($f['amount'],2) ?></td>
        <td><?= htmlspecialchars($f['due_date']) ?></td>
        <td><?= $f['paid_date'] ? htmlspecialchars($f['paid_date']) : '-' ?></td>
        <td>
          <?php if ($f['status']==='Paid'): ?>
            <span class="badge bg-success">Paid</span>
          <?php else: ?>
            <span class="badge bg-warning text-dark">Pending</span>
          <?php endif; ?>
        </td>
        <td><?= htmlspecialchars($f['remarks']) ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
