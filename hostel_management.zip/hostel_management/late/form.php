<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Log Late Entry';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $entry_date = $_POST['entry_date'];
    $entry_time = $_POST['entry_time'];
    $remarks = trim($_POST['remarks']);

    if (!$student_id || !$entry_date || !$entry_time) {
        $error = "Student, Date and Time are required.";
    } else {
        $isLate = $entry_time > CURFEW_TIME;

        $stmt = $pdo->prepare("INSERT INTO late_entries (student_id, entry_date, entry_time, remarks, alert_sent) VALUES (?,?,?,?,?)");
        $stmt->execute([$student_id, $entry_date, $entry_time, $remarks, $isLate ? 1 : 0]);

        if ($isLate) {
            $s = $pdo->prepare("SELECT name, roll_no, parent_name, parent_phone FROM students WHERE id = ?");
            $s->execute([$student_id]);
            $s = $s->fetch();
            $parentLabel = $s['parent_name'] ?: 'Parent/Guardian';
            $phoneLabel = $s['parent_phone'] ?: 'no phone on file';
            $message = "Dear {$parentLabel}, your ward {$s['name']} ({$s['roll_no']}) entered the hostel late at {$entry_time} on {$entry_date} (after curfew " . CURFEW_TIME . "). Sent to: {$phoneLabel}.";
            send_parent_alert($pdo, $student_id, 'Late Entry', $message);
        }

        header("Location: list.php?alert=" . ($isLate ? '1' : '0'));
        exit;
    }
}

$students = $pdo->query("SELECT id, name, roll_no FROM students ORDER BY name")->fetchAll();
include '../includes/header.php';
?>

<h3 class="page-title">Log Late Entry</h3>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:600px;">
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Student *</label>
    <select name="student_id" class="form-select" required>
      <option value="">-- Select --</option>
      <?php foreach ($students as $s): ?>
        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['roll_no']) ?>)</option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Entry Date *</label>
      <input type="date" name="entry_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">Entry Time *</label>
      <input type="time" name="entry_time" class="form-control" value="<?= date('H:i') ?>" required>
    </div>
  </div>
  <div class="mb-3">
    <label class="form-label">Remarks</label>
    <input type="text" name="remarks" class="form-control">
  </div>
  <div class="alert alert-info py-2 small">Curfew is <?= date('g:i A', strtotime(CURFEW_TIME)) ?>. Entries after this automatically log a parent alert with the message that would be sent.</div>
  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
  <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>
</div>

<?php include '../includes/footer.php'; ?>
