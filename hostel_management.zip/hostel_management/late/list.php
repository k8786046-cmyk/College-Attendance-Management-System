<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Late Entry';

$entries = $pdo->query("SELECT le.*, s.name, s.roll_no, s.parent_phone
                         FROM late_entries le JOIN students s ON le.student_id = s.id
                         ORDER BY le.entry_date DESC, le.entry_time DESC")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Late Entry Log</h3>
  <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Log Entry</a>
</div>

<?php if (isset($_GET['alert'])): ?>
  <div class="alert <?= $_GET['alert'] === '1' ? 'alert-warning' : 'alert-success' ?> py-2">
    <?= $_GET['alert'] === '1' ? 'Entry after curfew — a parent alert was logged.' : 'Entry recorded — within curfew, no alert needed.' ?>
  </div>
<?php endif; ?>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Student</th><th>Date</th><th>Time</th><th>Remarks</th><th>Parent Alert</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$entries): ?>
      <tr><td colspan="7">
        <div class="empty-state">
          <i class="fa-solid fa-clock"></i>
          <p>No late entries logged yet.</p>
          <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Log the first entry</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($entries as $e): ?>
      <tr>
        <td><?= $e['id'] ?></td>
        <td><?= htmlspecialchars($e['name']) ?> (<?= htmlspecialchars($e['roll_no']) ?>)</td>
        <td><?= htmlspecialchars($e['entry_date']) ?></td>
        <td><?= htmlspecialchars($e['entry_time']) ?><?= $e['entry_time'] > CURFEW_TIME ? ' <span class="badge bg-danger">Late</span>' : '' ?></td>
        <td><?= htmlspecialchars($e['remarks']) ?></td>
        <td>
          <?php if ($e['alert_sent']): ?>
            <span class="badge bg-warning text-dark"><i class="fa-solid fa-bell"></i> Sent to <?= htmlspecialchars($e['parent_phone'] ?: 'parent (no phone on file)') ?></span>
          <?php else: ?>
            <span class="text-muted">-</span>
          <?php endif; ?>
        </td>
        <td>
          <a href="delete.php?id=<?= $e['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this entry?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<p class="text-muted small mb-0 mt-2">Entries after <?= date('g:i A', strtotime(CURFEW_TIME)) ?> (curfew) automatically log a parent alert — see <a href="../alerts/list.php">Parent Alerts</a>.</p>
</div>

<?php include '../includes/footer.php'; ?>
