<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Students';

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare("SELECT s.*, r.room_no FROM students s LEFT JOIN rooms r ON s.room_id = r.id
                            WHERE s.name LIKE ? OR s.roll_no LIKE ? ORDER BY s.id DESC");
    $like = "%$search%";
    $stmt->execute([$like, $like]);
} else {
    $stmt = $pdo->query("SELECT s.*, r.room_no FROM students s LEFT JOIN rooms r ON s.room_id = r.id ORDER BY s.id DESC");
}
$students = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Students</h3>
  <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Student</a>
</div>

<form class="row g-2 mb-3" method="GET">
  <div class="col-auto">
    <input type="text" name="q" class="form-control" placeholder="Search by name or roll no" value="<?= htmlspecialchars($search) ?>">
  </div>
  <div class="col-auto">
    <button class="btn btn-outline-secondary"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
  </div>
</form>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr>
      <th>#</th><th>Name</th><th>Roll No</th><th>Course</th><th>Year</th>
      <th>Phone</th><th>Room</th><th>Admission Date</th><th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php if (!$students): ?>
      <tr><td colspan="9">
        <div class="empty-state">
          <i class="fa-solid fa-user-graduate"></i>
          <p><?= $search !== '' ? 'No students match "' . htmlspecialchars($search) . '".' : 'No students on record yet.' ?></p>
          <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add the first student</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($students as $s): ?>
      <tr>
        <td><?= $s['id'] ?></td>
        <td><?= htmlspecialchars($s['name']) ?></td>
        <td><?= htmlspecialchars($s['roll_no']) ?></td>
        <td><?= htmlspecialchars($s['course']) ?></td>
        <td><?= htmlspecialchars($s['year']) ?></td>
        <td><?= htmlspecialchars($s['phone']) ?></td>
        <td><?= $s['room_no'] ? htmlspecialchars($s['room_no']) : '<span class="text-muted">Unassigned</span>' ?></td>
        <td><?= htmlspecialchars($s['admission_date']) ?></td>
        <td>
          <a href="view.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-secondary" title="View details"><i class="fa-solid fa-eye"></i></a>
          <a href="form.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
          <a href="delete.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this student? This also removes their fees/complaints/attendance records.');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
