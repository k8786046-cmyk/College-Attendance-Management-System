<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';

$id = $_GET['id'] ?? null;
$stmt = $pdo->prepare("SELECT s.*, r.room_no, r.room_type FROM students s LEFT JOIN rooms r ON s.room_id = r.id WHERE s.id = ?");
$stmt->execute([$id]);
$s = $stmt->fetch();
if (!$s) { header("Location: list.php"); exit; }

$page_title = $s['name'];

$paid = $pdo->prepare("SELECT COALESCE(SUM(amount),0) t FROM fees WHERE student_id = ? AND status='Paid'");
$paid->execute([$id]);
$totalPaid = $paid->fetch()['t'];

$pending = $pdo->prepare("SELECT COALESCE(SUM(amount),0) t FROM fees WHERE student_id = ? AND status='Pending'");
$pending->execute([$id]);
$totalPending = $pending->fetch()['t'];

$presentDays = $pdo->prepare("SELECT COUNT(*) c FROM attendance WHERE student_id = ? AND status='Present'");
$presentDays->execute([$id]);
$presentDays = $presentDays->fetch()['c'];

$absentDays = $pdo->prepare("SELECT COUNT(*) c FROM attendance WHERE student_id = ? AND status='Absent'");
$absentDays->execute([$id]);
$absentDays = $absentDays->fetch()['c'];

$daysInHostel = null;
if (!empty($s['admission_date'])) {
    $adm = new DateTime($s['admission_date']);
    $today = new DateTime();
    if ($adm <= $today) $daysInHostel = $adm->diff($today)->days + 1;
}

$fees = $pdo->prepare("SELECT * FROM fees WHERE student_id = ? ORDER BY due_date DESC");
$fees->execute([$id]);
$fees = $fees->fetchAll();

$leaves = $pdo->prepare("SELECT *, DATEDIFF(to_date, from_date) + 1 AS days FROM leaves WHERE student_id = ? ORDER BY applied_on DESC");
$leaves->execute([$id]);
$leaves = $leaves->fetchAll();

include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title"><?= htmlspecialchars($s['name']) ?> <span class="text-muted small">(<?= htmlspecialchars($s['roll_no']) ?>)</span></h3>
  <div class="d-flex gap-2">
    <a href="form.php?id=<?= $s['id'] ?>" class="btn btn-outline-primary btn-sm"><i class="fa-solid fa-pen"></i> Edit</a>
    <a href="list.php" class="btn btn-outline-secondary btn-sm">Back to Students</a>
  </div>
</div>

<div class="stat-strip mb-3">
  <div class="stat-block">
    <i class="fa-solid fa-door-open stat-icon"></i>
    <div class="stat-num" style="font-size:1.4rem;"><?= $s['room_no'] ? htmlspecialchars($s['room_no']) : 'Unassigned' ?></div>
    <div class="stat-label">Room</div>
  </div>
  <div class="stat-block">
    <i class="fa-solid fa-calendar-day stat-icon"></i>
    <div class="stat-num"><?= $daysInHostel !== null ? $daysInHostel : '-' ?></div>
    <div class="stat-label">Days in Hostel</div>
  </div>
  <div class="stat-block">
    <i class="fa-solid fa-money-bill-wave stat-icon"></i>
    <div class="stat-num" style="font-size:1.2rem;">₹<?= number_format($totalPaid,2) ?></div>
    <div class="stat-label">Total Fees Paid</div>
  </div>
  <div class="stat-block <?= $totalPending > 0 ? 'flag' : '' ?>">
    <i class="fa-solid fa-money-bill stat-icon"></i>
    <div class="stat-num" style="font-size:1.2rem;">₹<?= number_format($totalPending,2) ?></div>
    <div class="stat-label">Total Fees Pending</div>
  </div>
  <div class="stat-block">
    <i class="fa-solid fa-calendar-check stat-icon"></i>
    <div class="stat-num"><?= $presentDays ?>/<?= $presentDays + $absentDays ?></div>
    <div class="stat-label">Attendance (Present/Marked)</div>
  </div>
</div>

<div class="card p-3 mb-3">
  <div class="panel-title">Details</div>
  <table class="table mb-0">
    <tr><th style="width:180px;">Course / Year</th><td><?= htmlspecialchars($s['course']) ?> / <?= htmlspecialchars($s['year']) ?></td></tr>
    <tr><th>Phone</th><td><?= htmlspecialchars($s['phone']) ?></td></tr>
    <tr><th>Email</th><td><?= htmlspecialchars($s['email']) ?></td></tr>
    <tr><th>Address</th><td><?= htmlspecialchars($s['address']) ?></td></tr>
    <tr><th>Parent Name / Phone</th><td><?= htmlspecialchars($s['parent_name']) ?> / <?= htmlspecialchars($s['parent_phone']) ?></td></tr>
    <tr><th>Admission Date</th><td><?= htmlspecialchars($s['admission_date']) ?></td></tr>
  </table>
</div>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card p-3 h-100">
      <div class="panel-title">Fee Records</div>
      <table class="table table-sm mb-0">
        <thead><tr><th>Amount</th><th>Due</th><th>Status</th><th>Remarks</th></tr></thead>
        <tbody>
          <?php if (!$fees): ?><tr><td colspan="4" class="text-muted">No fee records.</td></tr><?php endif; ?>
          <?php foreach ($fees as $f):
              $isCredit = $f['amount'] < 0;
          ?>
            <tr>
              <td class="<?= $isCredit ? 'text-success' : '' ?>"><?= $isCredit ? '− ₹' . number_format(abs($f['amount']),2) . ' (credit)' : '₹' . number_format($f['amount'],2) ?></td>
              <td><?= htmlspecialchars($f['due_date']) ?></td>
              <td><span class="badge <?= $f['status']==='Paid'?'bg-success':'bg-warning text-dark' ?>"><?= $f['status'] ?></span></td>
              <td class="small text-muted"><?= htmlspecialchars($f['remarks']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card p-3 h-100">
      <div class="panel-title">Leave History</div>
      <table class="table table-sm mb-0">
        <thead><tr><th>From</th><th>To</th><th>Days</th><th>Status</th><th>Reduction</th></tr></thead>
        <tbody>
          <?php if (!$leaves): ?><tr><td colspan="5" class="text-muted">No leave records.</td></tr><?php endif; ?>
          <?php foreach ($leaves as $l): ?>
            <tr>
              <td><?= htmlspecialchars($l['from_date']) ?></td>
              <td><?= htmlspecialchars($l['to_date']) ?></td>
              <td><?= $l['days'] ?></td>
              <td><?php $badge = ['Pending'=>'bg-warning text-dark','Approved'=>'bg-success','Rejected'=>'bg-danger'][$l['status']]; ?><span class="badge <?= $badge ?>"><?= $l['status'] ?></span></td>
              <td><?= $l['fee_adjusted'] && $l['reduction_amount']>0 ? '₹'.number_format($l['reduction_amount'],2) : '-' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
