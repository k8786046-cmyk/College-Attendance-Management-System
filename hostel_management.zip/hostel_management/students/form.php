<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';

$id = $_GET['id'] ?? null;
$student = ['name'=>'','roll_no'=>'','course'=>'','year'=>'','phone'=>'','email'=>'','address'=>'','parent_name'=>'','parent_phone'=>'','room_id'=>'','admission_date'=>date('Y-m-d')];
$error = '';

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if ($found) $student = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $roll_no = trim($_POST['roll_no']);
    $course = trim($_POST['course']);
    $year = trim($_POST['year']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $parent_name = trim($_POST['parent_name']);
    $parent_phone = trim($_POST['parent_phone']);
    $new_room_id = $_POST['room_id'] !== '' ? (int)$_POST['room_id'] : null;
    $admission_date = $_POST['admission_date'];
    $new_password = trim($_POST['password'] ?? '');

    if ($name === '' || $roll_no === '') {
        $error = "Name and Roll No are required.";
    } else {
        try {
            $pdo->beginTransaction();

            $old_room_id = $id ? $student['room_id'] : null;

            if ($id) {
                if ($new_password !== '') {
                    $stmt = $pdo->prepare("UPDATE students SET name=?, roll_no=?, course=?, year=?, phone=?, email=?, address=?, parent_name=?, parent_phone=?, room_id=?, admission_date=?, password=? WHERE id=?");
                    $stmt->execute([$name,$roll_no,$course,$year,$phone,$email,$address,$parent_name,$parent_phone,$new_room_id,$admission_date,password_hash($new_password, PASSWORD_BCRYPT),$id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE students SET name=?, roll_no=?, course=?, year=?, phone=?, email=?, address=?, parent_name=?, parent_phone=?, room_id=?, admission_date=? WHERE id=?");
                    $stmt->execute([$name,$roll_no,$course,$year,$phone,$email,$address,$parent_name,$parent_phone,$new_room_id,$admission_date,$id]);
                }
            } else {
                // Default login password = roll number if admin didn't set one
                $login_password = $new_password !== '' ? $new_password : $roll_no;
                $stmt = $pdo->prepare("INSERT INTO students (name, roll_no, course, year, phone, email, address, parent_name, parent_phone, room_id, admission_date, password) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
                $stmt->execute([$name,$roll_no,$course,$year,$phone,$email,$address,$parent_name,$parent_phone,$new_room_id,$admission_date,password_hash($login_password, PASSWORD_BCRYPT)]);
            }

            // Adjust room occupancy if the room assignment changed
            if ($old_room_id != $new_room_id) {
                if ($old_room_id) {
                    $pdo->prepare("UPDATE rooms SET occupied = GREATEST(occupied-1,0) WHERE id=?")->execute([$old_room_id]);
                }
                if ($new_room_id) {
                    $pdo->prepare("UPDATE rooms SET occupied = occupied+1 WHERE id=?")->execute([$new_room_id]);
                }
            }

            $pdo->commit();
            header("Location: list.php");
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Roll No already exists or an error occurred.";
        }
    }
}

// Rooms with vacancy (or the student's current room)
$rooms = $pdo->query("SELECT * FROM rooms WHERE occupied < capacity OR id = " . (int)($student['room_id'] ?? 0) . " ORDER BY room_no")->fetchAll();

$page_title = $id ? 'Edit Student' : 'Add Student';
include '../includes/header.php';
?>

<h3 class="page-title"><?= $page_title ?></h3>

<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:700px;">
<form method="POST">
  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Full Name *</label>
      <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($student['name']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Roll No *</label>
      <input type="text" name="roll_no" class="form-control" value="<?= htmlspecialchars($student['roll_no']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Course</label>
      <input type="text" name="course" class="form-control" value="<?= htmlspecialchars($student['course']) ?>" placeholder="e.g. B.Sc CS">
    </div>
    <div class="col-md-6">
      <label class="form-label">Year</label>
      <input type="text" name="year" class="form-control" value="<?= htmlspecialchars($student['year']) ?>" placeholder="e.g. 3rd Year">
    </div>
    <div class="col-md-6">
      <label class="form-label">Phone</label>
      <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($student['phone']) ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($student['email']) ?>">
    </div>
    <div class="col-12">
      <label class="form-label">Address</label>
      <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($student['address']) ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Parent/Guardian Name</label>
      <input type="text" name="parent_name" class="form-control" value="<?= htmlspecialchars($student['parent_name'] ?? '') ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Parent/Guardian Phone</label>
      <input type="text" name="parent_phone" class="form-control" value="<?= htmlspecialchars($student['parent_phone'] ?? '') ?>">
      <div class="form-text">Used for late-entry alerts.</div>
    </div>
    <div class="col-md-6">
      <label class="form-label">Room</label>
      <select name="room_id" class="form-select">
        <option value="">-- Unassigned --</option>
        <?php foreach ($rooms as $r): ?>
          <option value="<?= $r['id'] ?>" <?= $student['room_id'] == $r['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($r['room_no']) ?> (<?= $r['occupied'] ?>/<?= $r['capacity'] ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-6">
      <label class="form-label">Admission Date</label>
      <input type="date" name="admission_date" class="form-control" value="<?= htmlspecialchars($student['admission_date']) ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Student Login Password</label>
      <input type="text" name="password" class="form-control" placeholder="<?= $id ? 'Leave blank to keep unchanged' : 'Leave blank to default to Roll No' ?>">
      <div class="form-text">Student uses Roll No + this password to log in at the student portal.</div>
    </div>
  </div>
  <div class="mt-4">
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
    <a href="list.php" class="btn btn-secondary">Cancel</a>
  </div>
</form>
</div>

<?php include '../includes/footer.php'; ?>
