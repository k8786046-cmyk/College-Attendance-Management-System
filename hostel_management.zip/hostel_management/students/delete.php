<?php
require '../includes/auth.php';
require '../config/db.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("SELECT room_id FROM students WHERE id = ?");
    $stmt->execute([$id]);
    $s = $stmt->fetch();

    $pdo->prepare("DELETE FROM students WHERE id = ?")->execute([$id]);

    if ($s && $s['room_id']) {
        $pdo->prepare("UPDATE rooms SET occupied = GREATEST(occupied-1,0) WHERE id=?")->execute([$s['room_id']]);
    }
}
header("Location: list.php");
exit;
