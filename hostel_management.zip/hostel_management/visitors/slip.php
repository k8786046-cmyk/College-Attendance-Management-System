<?php
require '../includes/auth.php';
require '../config/db.php';

$id = $_GET['id'] ?? null;
$stmt = $pdo->prepare("SELECT v.*, s.name, s.roll_no, s.phone FROM visitors v JOIN students s ON v.student_id = s.id WHERE v.id = ?");
$stmt->execute([$id]);
$visitor = $stmt->fetch();
if (!$visitor) { header("Location: list.php"); exit; }

$rules = $pdo->query("SELECT * FROM rules ORDER BY sort_order, id")->fetchAll();
$feeItems = $pdo->query("SELECT * FROM fee_structure ORDER BY sort_order, id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Visitor Slip - Hostel Management System</title>
<link href="../assets/img/favicon.svg" rel="icon" type="image/svg+xml">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
<style>
  @media print { .no-print { display: none !important; } body { background: #fff !important; } }
  .slip-wrap { max-width: 760px; margin: 0 auto; }
</style>
</head>
<body class="home-body">

<nav class="navbar navbar-dark hms-navbar px-3 no-print">
  <span class="brand-mark">Hostel Management System <span class="portal-tag">Visitor Slip</span></span>
  <div class="d-flex gap-2">
    <button class="btn btn-sm btn-brass" onclick="window.print()"><i class="fa-solid fa-print"></i> Print</button>
    <a href="list.php" class="btn btn-sm btn-outline-light">Back to Visitors</a>
  </div>
</nav>

<div class="slip-wrap p-4">
  <div class="text-center mb-4">
    <h2 class="mb-0">Visitor Pass &amp; Hostel Guidelines</h2>
  </div>

  <div class="card p-4 mb-4">
    <div class="panel-title">Visit Details</div>
    <table class="table mb-0">
      <tr><th style="width:180px;">Visitor Name</th><td><?= htmlspecialchars($visitor['visitor_name']) ?></td></tr>
      <tr><th>Meeting Student</th><td><?= htmlspecialchars($visitor['name']) ?> (<?= htmlspecialchars($visitor['roll_no']) ?>)</td></tr>
      <tr><th>Purpose</th><td><?= htmlspecialchars($visitor['purpose']) ?></td></tr>
      <tr><th>Visit Date</th><td><?= htmlspecialchars($visitor['visit_date']) ?></td></tr>
      <tr><th>In Time</th><td><?= htmlspecialchars($visitor['in_time']) ?></td></tr>
    </table>
  </div>

  <div class="card p-4 mb-4">
    <div class="panel-title">Hostel Rules</div>
    <?php if (!$rules): ?>
      <p class="text-muted mb-0">No rules have been added yet.</p>
    <?php else: ?>
      <ol class="mb-0">
        <?php foreach ($rules as $r): ?>
          <li class="mb-2">
            <strong><?= htmlspecialchars($r['title']) ?></strong><br>
            <span class="text-muted"><?= nl2br(htmlspecialchars($r['description'])) ?></span>
          </li>
        <?php endforeach; ?>
      </ol>
    <?php endif; ?>
  </div>

  <div class="card p-4 mb-4">
    <div class="panel-title">Fee Structure</div>
    <?php if (!$feeItems): ?>
      <p class="text-muted mb-0">No fee structure items have been added yet.</p>
    <?php else: ?>
      <table class="table mb-0">
        <thead><tr><th>Category</th><th>Amount</th><th>Period</th></tr></thead>
        <tbody>
          <?php foreach ($feeItems as $f): ?>
            <tr>
              <td><?= htmlspecialchars($f['category']) ?></td>
              <td>₹<?= number_format($f['amount'],2) ?></td>
              <td><?= htmlspecialchars($f['period']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <p class="text-muted small text-center no-print">Hand this slip (printed or on screen) to the visitor.</p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
