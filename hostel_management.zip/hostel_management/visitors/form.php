<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Log Visitor';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $visitor_name = trim($_POST['visitor_name']);
    $purpose = trim($_POST['purpose']);
    $visit_date = $_POST['visit_date'];
    $in_time = $_POST['in_time'];

    if (!$student_id || $visitor_name === '') {
        $error = "Student and Visitor Name are required.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO visitors (student_id, visitor_name, purpose, visit_date, in_time) VALUES (?,?,?,?,?)");
        $stmt->execute([$student_id, $visitor_name, $purpose, $visit_date, $in_time]);
        header("Location: list.php");
        exit;
    }
}

$students = $pdo->query("SELECT id, name, roll_no FROM students ORDER BY name")->fetchAll();
include '../includes/header.php';
?>

<h3 class="page-title">Log Visitor</h3>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:600px;">
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Meeting Student *</label>
    <select name="student_id" class="form-select" required>
      <option value="">-- Select --</option>
      <?php foreach ($students as $s): ?>
        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['roll_no']) ?>)</option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="mb-3">
    <label class="form-label">Visitor Name *</label>
    <input type="text" name="visitor_name" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Purpose</label>
    <input type="text" name="purpose" class="form-control">
  </div>
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Visit Date</label>
      <input type="date" name="visit_date" class="form-control" value="<?= date('Y-m-d') ?>">
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">In Time</label>
      <input type="time" name="in_time" class="form-control" value="<?= date('H:i') ?>">
    </div>
  </div>
  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
  <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>
</div>

<?php include '../includes/footer.php'; ?>
