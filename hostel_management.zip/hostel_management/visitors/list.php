<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Visitors';

$visitors = $pdo->query("SELECT v.*, s.name, s.roll_no FROM visitors v JOIN students s ON v.student_id = s.id ORDER BY v.id DESC")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Visitors Log</h3>
  <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Log Visitor</a>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Visitor</th><th>Meeting</th><th>Purpose</th><th>Date</th><th>In Time</th><th>Out Time</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$visitors): ?>
      <tr><td colspan="8">
        <div class="empty-state">
          <i class="fa-solid fa-address-book"></i>
          <p>No visitors logged yet.</p>
          <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Log the first visitor</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($visitors as $v): ?>
      <tr>
        <td><?= $v['id'] ?></td>
        <td><?= htmlspecialchars($v['visitor_name']) ?></td>
        <td><?= htmlspecialchars($v['name']) ?> (<?= htmlspecialchars($v['roll_no']) ?>)</td>
        <td><?= htmlspecialchars($v['purpose']) ?></td>
        <td><?= htmlspecialchars($v['visit_date']) ?></td>
        <td><?= htmlspecialchars($v['in_time']) ?></td>
        <td>
          <?php if ($v['out_time']): ?>
            <?= htmlspecialchars($v['out_time']) ?>
          <?php else: ?>
            <a href="checkout.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-success">Mark Checkout</a>
          <?php endif; ?>
        </td>
        <td>
          <a href="slip.php?id=<?= $v['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="Rules &amp; Fee slip"><i class="fa-solid fa-file-lines"></i></a>
          <a href="delete.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this visitor record?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
