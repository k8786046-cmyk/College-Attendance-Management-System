<?php
require '../includes/auth.php';
require '../config/db.php';
$id = $_GET['id'] ?? null;
if ($id) {
    $pdo->prepare("UPDATE visitors SET out_time = ? WHERE id = ?")->execute([date('H:i:s'), $id]);
}
header("Location: list.php");
exit;
