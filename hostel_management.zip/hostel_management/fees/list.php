<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';
$page_title = 'Fees';

$fees = $pdo->query("SELECT f.*, s.name, s.roll_no FROM fees f JOIN students s ON f.student_id = s.id ORDER BY f.id DESC")->fetchAll();
include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="page-title">Fees</h3>
  <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Record Fee</a>
</div>

<div class="card p-3">
<table class="table table-hover align-middle">
  <thead>
    <tr><th>#</th><th>Student</th><th>Roll No</th><th>Amount</th><th>Due Date</th><th>Paid Date</th><th>Status</th><th>Actions</th></tr>
  </thead>
  <tbody>
    <?php if (!$fees): ?>
      <tr><td colspan="8">
        <div class="empty-state">
          <i class="fa-solid fa-money-bill"></i>
          <p>No fee records yet.</p>
          <a href="form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Record the first fee</a>
        </div>
      </td></tr>
    <?php endif; ?>
    <?php foreach ($fees as $f): $isCredit = $f['amount'] < 0; ?>
      <tr>
        <td><?= $f['id'] ?></td>
        <td><?= htmlspecialchars($f['name']) ?></td>
        <td><?= htmlspecialchars($f['roll_no']) ?></td>
        <td class="<?= $isCredit ? 'text-success' : '' ?>"><?= $isCredit ? '− ₹' . number_format(abs($f['amount']),2) . ' <span class="badge bg-success">Credit</span>' : '₹' . number_format($f['amount'],2) ?></td>
        <td><?= htmlspecialchars($f['due_date']) ?></td>
        <td><?= $f['paid_date'] ? htmlspecialchars($f['paid_date']) : '-' ?></td>
        <td>
          <?php if ($f['status']==='Paid'): ?>
            <span class="badge bg-success">Paid</span>
          <?php else: ?>
            <span class="badge bg-warning text-dark">Pending</span>
          <?php endif; ?>
        </td>
        <td>
          <a href="form.php?id=<?= $f['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
          <a href="delete.php?id=<?= $f['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this fee record?');"><i class="fa-solid fa-trash"></i></a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php include '../includes/footer.php'; ?>
