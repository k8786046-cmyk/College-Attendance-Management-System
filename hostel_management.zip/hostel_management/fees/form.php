<?php
require '../includes/auth.php';
require '../config/db.php';
$base = '../';

$id = $_GET['id'] ?? null;
$fee = ['student_id'=>'','amount'=>'','due_date'=>date('Y-m-d'),'paid_date'=>'','status'=>'Pending','remarks'=>''];
$error = '';

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM fees WHERE id = ?");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if ($found) $fee = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $amount = $_POST['amount'];
    $due_date = $_POST['due_date'];
    $status = $_POST['status'];
    $paid_date = $status === 'Paid' ? ($_POST['paid_date'] ?: date('Y-m-d')) : null;
    $remarks = trim($_POST['remarks']);

    if (!$student_id || $amount === '') {
        $error = "Student and Amount are required.";
    } else {
        if ($id) {
            $stmt = $pdo->prepare("UPDATE fees SET student_id=?, amount=?, due_date=?, paid_date=?, status=?, remarks=? WHERE id=?");
            $stmt->execute([$student_id,$amount,$due_date,$paid_date,$status,$remarks,$id]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO fees (student_id, amount, due_date, paid_date, status, remarks) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$student_id,$amount,$due_date,$paid_date,$status,$remarks]);
        }
        header("Location: list.php");
        exit;
    }
}

$students = $pdo->query("SELECT id, name, roll_no FROM students ORDER BY name")->fetchAll();
$page_title = $id ? 'Edit Fee Record' : 'Record Fee';
include '../includes/header.php';
?>

<h3 class="page-title"><?= $page_title ?></h3>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="card p-4" style="max-width:600px;">
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Student *</label>
    <select name="student_id" class="form-select" required>
      <option value="">-- Select --</option>
      <?php foreach ($students as $s): ?>
        <option value="<?= $s['id'] ?>" <?= $fee['student_id']==$s['id']?'selected':'' ?>><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['roll_no']) ?>)</option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Amount (₹) *</label>
      <input type="number" step="0.01" name="amount" class="form-control" value="<?= htmlspecialchars($fee['amount']) ?>" required>
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">Due Date</label>
      <input type="date" name="due_date" class="form-control" value="<?= htmlspecialchars($fee['due_date']) ?>">
    </div>
  </div>
  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="Pending" <?= $fee['status']==='Pending'?'selected':'' ?>>Pending</option>
        <option value="Paid" <?= $fee['status']==='Paid'?'selected':'' ?>>Paid</option>
      </select>
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">Paid Date</label>
      <input type="date" name="paid_date" class="form-control" value="<?= htmlspecialchars($fee['paid_date']) ?>">
    </div>
  </div>
  <div class="mb-3">
    <label class="form-label">Remarks</label>
    <input type="text" name="remarks" class="form-control" value="<?= htmlspecialchars($fee['remarks']) ?>">
  </div>
  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
  <a href="list.php" class="btn btn-secondary">Cancel</a>
</form>
</div>

<?php include '../includes/footer.php'; ?>
